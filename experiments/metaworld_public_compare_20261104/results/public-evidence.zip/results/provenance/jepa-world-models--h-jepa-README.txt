---
license: cc-by-4.0
pretty_name: H-JEPA datasets
tags:
- robotics
- world-models
- video
---

# H-JEPA datasets

[![arXiv](https://img.shields.io/badge/arXiv-2610.06805-b5212f?logo=arxiv)](https://arxiv.org/abs/2610.06805)
[![Website](https://img.shields.io/badge/Website-h--jepa.com-blue)](https://h-jepa.com/)
[![Code](https://img.shields.io/badge/GitHub-kevinghst/H--JEPA-black?logo=github)](https://github.com/kevinghst/H-JEPA)
[![Models](https://img.shields.io/badge/🤗%20Models-jepa--world--models/h--jepa-ffc107)](https://huggingface.co/jepa-world-models/h-jepa)

Data for the H-JEPA code release (hierarchical JEPA world models). Image columns are stored with
lossless Blosc-Zstd compression inside the HDF5 files; `h5py` with `hdf5plugin` reads them directly. The repository mirrors
`$HJEPA_HOME`, the data root the code reads from, so a download with `--local-dir $HJEPA_HOME`
puts every file where the code expects it.

## FourRoom Distractors

The four-room navigation environment with one distractor agent that wanders and teleports (Poisson,
mean interval 35 steps), rendered at 224x224. The controlled agent follows a noisy expert policy in
half of the episodes and a random exploration policy in the other half. Every episode has 401 frames.

```bash
hf download jepa-world-models/h-jepa --repo-type dataset --local-dir $HJEPA_HOME --include "fourroom_tp35_d1*"
```

| Path | Episodes | Size | Used for |
|---|---|---|---|
| `fourroom_tp35_d1.h5` | 3,750 | 4.1 GB | training (the configs read 1.0M of its 1.5M transitions) |
| `fourroom_tp35_d1_val.h5` | 150 | 0.2 GB | validation; source of the planning-evaluation tasks |
| `fourroom_tp35_d1_probing.h5` | 600 | 0.7 GB | probe training |
| `fourroom_tp35_d1_probing_val.h5` | 150 | 0.2 GB | probe evaluation |

All four files come from one collection seed, so the validation and probing files are the first
150 / 600 / 150 episodes of the training file. `scripts/data/collect_datasets.sh` in the code
release regenerates them (identical in our checks).

## Visual AntMaze

Rollouts of the OGBench AntMaze expert policies in the `medium` maze, rendered at 64x64 from the
`back` camera. Every episode has 402 frames.

```bash
hf download jepa-world-models/h-jepa --repo-type dataset --local-dir $HJEPA_HOME --include "visual_antmaze_medium_*"
```

| Path | Episodes | Size | Used for |
|---|---|---|---|
| `visual_antmaze_medium_explore_stitch_train.h5` | 25,000 (12,500 explore + 12,500 stitch) | 22.0 GB | training |
| `visual_antmaze_medium_stitch_val.h5` | 1,250 stitch | 1.4 GB | validation; source of the planning-evaluation tasks |
| `visual_antmaze_medium_probing_train.h5` | 3,106 (1,555 explore + 1,551 stitch) | 3.4 GB | probe training |
| `visual_antmaze_medium_probing_eval.h5` | 310 (155 explore + 155 stitch) | 0.3 GB | probe evaluation |

The training file is the training data of the seed-42 paper models and holds only the columns
training reads (`pixels`, `action`, `xy`, `qpos`, `qvel`, `proprio`, plus the episode index
columns); the other files keep every column the collector records except `observation`, a copy of
`pixels`. `scripts/data/collect_datasets.sh`
in the code release collects files from the same distribution (not byte-identical).

## Push-T and OGBench Cube

The training data of these two environments is LeWM's release:
[`quentinll/lewm-pusht`](https://huggingface.co/datasets/quentinll/lewm-pusht) and
[`quentinll/lewm-cube`](https://huggingface.co/datasets/quentinll/lewm-cube) (MIT). This repository
adds only `pusht_expert_val.h5` (21 episodes, 16 MB, with the `block_ori` column), the Push-T
validation set, converted from DINO-WM's Push-T validation data. The code release's README lists
the download and preparation commands (`add_pusht_block_ori.py`, `split_cube.py`).

## DROID

A copy of [DROID](https://droid-dataset.github.io/) 1.0.1 prepared for H-JEPA training and the
offline DROID planning evaluation.

```bash
hf download jepa-world-models/h-jepa --repo-type dataset --local-dir $HJEPA_HOME --include "droid/*"
bash $HJEPA_HOME/droid/extract.sh            # add --delete to remove each tar once extracted
```

`extract.sh` checks `SHA256SUMS`, then untars every shard in place (`JOBS=8` in parallel). The
loader (`h_jepa/droid_data.py`) resolves relative paths (the CSVs, their entries and the manifest's
`episode_path`) against `$HJEPA_HOME/droid`.

| Path | Content |
|---|---|
| `droid/droid_paths_minus16_256p.csv` | training split: 74,896 episodes (`<episode dir> <index>`, relative paths) |
| `droid/droid_val_indist_256p.csv` | validation split used for monitoring: 64 episodes (62 of them also in the training CSV) |
| `droid/droid_256p/shard-{00000..00060}.tar` | 61 tar shards (90.9 GB, 0.56-1.52 GB each): the 256x256 training corpus, extracting to `droid/droid_256p/1.0.1/<lab>/<success\|failure>/<date>/<episode>/` |
| `droid/droid_raw_eval16.tar` | 0.25 GB: the 16 raw DROID 1.0.1 episodes of the planning-evaluation manifest, extracting to `droid/droid_raw/1.0.1/...` |
| `droid/SHA256SUMS`, `droid/extract.sh` | tar checksums and the extraction script |

**Training corpus (`droid_256p`).** DROID 1.0.1 re-encoded to 256x256 mp4, all episodes minus the 16
evaluation episodes. Each episode directory holds the files the loader reads: the DROID metadata
json, `trajectory.npz` (the `cartesian_position`, `gripper_position` and `camera_extrinsics/*`
arrays of DROID's `trajectory.h5`) and the two exterior-camera mp4s
(`recordings/MP4/<serial>.mp4`, the `left_mp4_path` and `right_mp4_path` views of the metadata;
the wrist camera is not included). The mp4 containers are tagged 60 fps but hold DROID's 15 Hz
footage; the models use every third frame (5 fps). Totals: 74,516 episode directories, 295,718 files,
90.4 GB. As in the paper runs, 382 CSV entries have no episode directory and 1,191 episodes lack
one or both exterior mp4s; the loader replaces a clip that fails to load by another random episode,
so these entries are kept to reproduce the paper's sampling exactly.

**Evaluation episodes (`droid_raw`).** The 16 episodes read by the planning-evaluation manifest
(`h_jepa/droid_assets/droid_clips_waypoint_curated16v2_5fps_gw36.json`), as in the raw DROID 1.0.1
release (1280x720 mp4): per episode the metadata json, `trajectory.h5` and the left exterior-camera
mp4 (48 files).

**License and attribution.** DROID is released by its authors under
[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/); this re-encoded subset is redistributed
under the same license. The changes are the 256x256 re-encoding, the `trajectory.npz` extraction
and the file selection above. Please cite DROID when using this data:

```bibtex
@inproceedings{khazatsky2024droid,
  title     = {{DROID}: A Large-Scale In-The-Wild Robot Manipulation Dataset},
  author    = {Khazatsky, Alexander and Pertsch, Karl and Nair, Suraj and Balakrishna, Ashwin and
               Dasari, Sudeep and Karamcheti, Siddharth and Nasiriany, Soroush and Srirama, Mohan Kumar
               and Chen, Lawrence Yunliang and Ellis, Kirsty and others},
  booktitle = {Robotics: Science and Systems},
  year      = {2024}
}
```

## Checksums

The root `SHA256SUMS` lists the FourRoom, AntMaze and Push-T validation files (DROID has its own `droid/SHA256SUMS`):
`cd $HJEPA_HOME && sha256sum -c --ignore-missing SHA256SUMS`.

## Citation

If you use these datasets, please cite H-JEPA (and DROID for the DROID data, see above):

```bibtex
@article{zhang2026hjepa,
  title   = {{H-JEPA}: End-to-End Learning of Hierarchical World Models for Visual Planning},
  author  = {Zhang, Wancong and Terver, Basile and Rabbat, Mike and LeCun, Yann and Balestriero, Randall},
  journal = {arXiv preprint arXiv:2610.06805},
  year    = {2026}
}
```
