---
license: mit
---

# Dataset Card for TD-MPC2


Official dataset release for the paper

[Scalable, Robust World Models for Continuous Control](https://nicklashansen.github.io/td-mpc2) by

[Nicklas Hansen](https://nicklashansen.github.io), [Hao Su](https://cseweb.ucsd.edu/~haosu)\*, [Xiaolong Wang](https://xiaolonw.github.io)\* (UC San Diego)

**Quick links:** [[Website]](https://nicklashansen.github.io/td-mpc2) [[Paper]](https://arxiv.org/abs/2310.16828) [[Models]](https://huggingface.co/nicklashansen/tdmpc2)

## Dataset Details

We open-source all data corresponding to the 80-task and 30-task datasets used in our multi-task experiments. The two datasets contain 545M and 345M transitions, respectively. The data is obtained from the replay buffers of 240 single-task TD-MPC2 agents, and thus contain a wide variety of behaviors ranging from random to expert policies. This section aims to provide further details about the released datasets.

### Dataset Description

- **Curated by:** [Nicklas Hansen](https://nicklashansen.github.io) (UC San Diego)
- **License:** MIT

### Dataset Sources

- **Repository:** [https://github.com/nicklashansen/tdmpc2](https://github.com/nicklashansen/tdmpc2)
- **Paper:** [https://arxiv.org/abs/2310.16828](https://arxiv.org/abs/2310.16828)

### Source Data

Our data is collected by 240 single-task TD-MPC2 agents trained on 104 continuous control tasks from DMControl, Meta-World, Maniskill2, and MyoSuite.

| Dataset | Embodiments | Max obs | Max action | Episodes | Transitions | Size |
|---------|:-----------:|:-------:|:----------:|:--------:|:-----------:|:----:|
| MT80 | 12 | 39 | 6 | 2.69M | 545M | 34 GB |
| MT30 | 11 | 24 | 6 | 690k | 345M | 20 GB |

See the [official website](https://nicklashansen.github.io/td-mpc2/dataset) for visualization of TD-MPC2 agents performing all of 80 tasks from the dataset.

## Citation

If you find our work useful, please consider citing the paper as follows:

**BibTeX:**
```
@misc{hansen2023tdmpc2,
      title={TD-MPC2: Scalable, Robust World Models for Continuous Control}, 
      author={Nicklas Hansen and Hao Su and Xiaolong Wang},
      year={2023},
      eprint={2310.16828},
      archivePrefix={arXiv},
      primaryClass={cs.LG}
}
```

## Contact

Correspondence to: [Nicklas Hansen](https://nicklashansen.github.io)