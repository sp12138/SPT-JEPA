---
tags:
- robotics
- world-model
- uncertainty
- calibration
---

# World Model Uncertainty raw half-validation caches

Lossless uint8 RGB clips and actions for deterministic Bridge, RoboNet, and
RT-1 calibration evaluation. Each directory is independently downloadable.
Its portable manifest fixes the selected episodes, clip starts, and SHA-256
of every array. These are raw pixel targets, not VAE latents.
