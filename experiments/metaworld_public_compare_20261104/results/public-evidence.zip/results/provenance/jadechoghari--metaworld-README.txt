---
license: apache-2.0
task_categories:
- robotics
tags:
- LeRobot
configs:
- config_name: default
  data_files: data/*/*.parquet
---

This dataset was created using [LeRobot](https://github.com/huggingface/lerobot).

## Dataset Description



- **Homepage:** [More Information Needed]
- **Paper:** [More Information Needed]
- **License:** apache-2.0

## Dataset Structure

[meta/info.json](meta/info.json):
```json
{
    "codebase_version": "v2.0",
    "robot_type": "metaworld",
    "total_episodes": 2500,
    "total_frames": 204806,
    "total_tasks": 49,
    "total_videos": 0,
    "total_chunks": 3,
    "chunks_size": 1000,
    "fps": 80,
    "splits": {
        "train": "0:2500"
    },
    "data_path": "data/chunk-{episode_chunk:03d}/episode_{episode_index:06d}.parquet",
    "video_path": "videos/chunk-{episode_chunk:03d}/{video_key}/episode_{episode_index:06d}.mp4",
    "features": {
        "observation.state": {
            "dtype": "float32",
            "shape": [
                4
            ],
            "names": {
                "axes": null
            }
        },
        "action": {
            "dtype": "float32",
            "shape": [
                4
            ],
            "names": {
                "axes": [
                    "x",
                    "y",
                    "z",
                    "gripper"
                ]
            }
        },
        "next.reward": {
            "dtype": "float32",
            "shape": [
                1
            ],
            "names": null
        },
        "next.success": {
            "dtype": "bool",
            "shape": [
                1
            ],
            "names": null
        },
        "observation.environment_state": {
            "dtype": "float32",
            "shape": [
                39
            ],
            "names": [
                "keypoints"
            ]
        },
        "observation.image": {
            "dtype": "image",
            "shape": [
                3,
                480,
                480
            ],
            "names": [
                "channels",
                "height",
                "width"
            ]
        },
        "task_id": {
            "dtype": "int16",
            "shape": [
                1
            ],
            "names": null
        },
        "timestamp": {
            "dtype": "float32",
            "shape": [
                1
            ],
            "names": null
        },
        "frame_index": {
            "dtype": "int64",
            "shape": [
                1
            ],
            "names": null
        },
        "episode_index": {
            "dtype": "int64",
            "shape": [
                1
            ],
            "names": null
        },
        "index": {
            "dtype": "int64",
            "shape": [
                1
            ],
            "names": null
        },
        "task_index": {
            "dtype": "int64",
            "shape": [
                1
            ],
            "names": null
        }
    }
}
```


## Citation

**BibTeX:**

```bibtex
[More Information Needed]
```