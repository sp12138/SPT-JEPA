---
license: mit
task_categories:
- reinforcement-learning
---
This repository contains the [Meta-World](https://arxiv.org/abs/1910.10897) datasets as used in [Learning to Modulate Pre-trained Models in RL](https://arxiv.org/abs/2306.14884): 
- The `2M` folder contains trajectories (2M transitions) for every task are stored as separate `.npz`.
- The `2M_separate` folder contains the same data, but every trajectory is stored as a separate `.hdf5` file and every task is stored as a `.tar.gz` file.


Download the dataset using the `huggingface-cli`:
```
huggingface-cli download ml-jku/meta-world --local-dir=./meta-world --repo-type dataset
```
For dataloading we refer to our Github repository: https://github.com/ml-jku/L2M

Citation:
```
@article{schmied2024learning,
  title={Learning to Modulate pre-trained Models in RL},
  author={Schmied, Thomas and Hofmarcher, Markus and Paischer, Fabian and Pascanu, Razvan and Hochreiter, Sepp},
  journal={Advances in Neural Information Processing Systems},
  volume={36},
  year={2024}
}
```