---
license: cc-by-4.0
language:
- en
task_categories:
- image-to-text
- image-feature-extraction
tags:
- video
- world-model
- frame-sequence
- temporal
- openvid
size_categories:
- 100K<n<1M
configs:
- config_name: index
  data_files: sequences.jsonl
- config_name: captions
  data_files: outputs/captions.jsonl
---

# OpenVid Frame Sequences — 1M adjacent frame pairs

Short, single-shot frame sequences cut from [OpenVid-1M](https://huggingface.co/datasets/nkp37/OpenVid-1M),
built to train and evaluate models on **what changes between two frames half a second apart**.

One sample = **10 consecutive frames, 0.5 s apart** (a 4.5 s span) → **9 adjacent frame pairs**.

```
[f00] --0.5s--> [f01] --0.5s--> [f02] ... [f09]
      ^ the thing you describe / predict
```

| | |
|---|---|
| Sequences | **116,596** |
| Frames per sequence | 10 (0.5 s apart, t = 0.0 … 4.5 s) |
| **Adjacent frame pairs** | **1,049,364** |
| Source clips | 87,002 (**at most 2 sequences per clip**) |
| Images | 1,165,960 JPEGs, 768 px wide, q=3, mean 44 KB |
| **Change captions** | **1,049,364** (one per adjacent pair, `outputs/captions.jsonl`) |
| Download size | ~53 GB (frames) + 145 MB (index) + 588 MB (captions) |

Source videos are **not** included — see [OpenVid-1M](https://huggingface.co/datasets/nkp37/OpenVid-1M)
for those. Every sequence carries the clip name and timestamps, so the source frames are recoverable.

## Change captions

`outputs/captions.jsonl` holds one English caption per adjacent pair describing only what visibly changes from the
earlier frame to the later one, written by Qwen3-VL-30B-A3B-Instruct from the two frames alone (prompt and
validation rules in [docs/caption_prompt.md](docs/caption_prompt.md)). They are the OpenVid action texts of
[LaLa-World](https://github.com/junha1125/LaLa-World).

```json
{"pair_id": "<clip>__w0:03", "sequence_id": "<clip>__w0", "pair_index": 3,
 "before_frame": "frames/a4/<clip>__w0/f03.jpg", "after_frame": "frames/a4/<clip>__w0/f04.jpg",
 "caption": "The plant's leaves shift slightly in position.", "word_count": 7, ...}
```

Every sequence has all nine pairs. Captions are at most 70 words (median 15). A pair that crosses a shot change
is captioned `A scene cut changes the view from ...` (0.45%) and a pair with nothing visibly moving
`No discernible change is visible.` (0.51%); both are kept.

## Why this exists

Video-caption datasets describe a whole clip. Training a model to reason about *change*
needs pairs that are close enough in time to share a scene, but far enough apart that
something actually happened. This dataset fixes that interval at 0.5 s and filters for
clips where motion is real, so that a difference caption between `f_i` and `f_i+1` is
never "nothing changed".

Measured on a uniform random sample: **mean absolute pixel change between adjacent frames
is 16.6 / 255** (median 15.5), and only **1.0%** of sequences are effectively static.

## Selection criteria

Applied to the full OpenVid-1M metadata (1,019,957 clips) before downloading a single byte:

```
motion score      ∈ [5.27, 60]     # 5.27 = top 29.5% of the candidate pool
aesthetic score   ≥ 5.0
duration          ≥ 4.75 s (one window) / ≥ 9.75 s (two windows)
sequences/clip    ≤ 2               # so no single video dominates the data
caption           must not match  talk|talking|interview|podcast
clip name         must not start with  celebv_  or  pixabay_
camera motion     unconstrained
```

Capping at 2 sequences per clip matters: without it a handful of long videos contribute
hundreds of near-identical sequences each.

Camera motion is deliberately **not** constrained — pans and zooms are themselves valid
visual change. The resulting mix is **63.4% static / 36.6% moving**
(pan_right 7.8%, pan_left 7.0%, undetermined 6.5%, zoom_in 2.8%, tilt_up 2.2%, …).

## Composition

| | |
|---|---|
| camera | static 63.4% · moving 36.6% |
| source resolution | 64.9% from 1080p originals (all resized to 768 px wide) |
| motion score | min 5.27 · p25 6.76 · **median 9.74** · p75 20.95 · max 60.00 |
| source clip length | median 9.8 s |
| windows per clip | 1 window: 57,408 clips · 2 windows: 29,594 clips |

## Files

```
frames/frames-000.tar … frames-063.tar   64 shards, ~850 MB each, 53 GB total
sequences.jsonl                          116,596 lines — the index
outputs/captions.jsonl                   1,049,364 lines — one change caption per adjacent pair
meta/manifest.csv                        111,536 rows: the full filtered candidate list
meta/part_index.jsonl                    1,019,957 rows: clip -> (OpenVid zip part, member, bytes)
scripts/                                 the pipeline that produced this
docs/                                    build runbook and result notes (Korean), caption prompt
```

Each tar extracts to `frames/<2-hex shard>/<clip>__w<N>/f00.jpg … f09.jpg`, which is exactly
the path written in `sequences.jsonl`. Extract every shard into the same directory and the
index paths resolve as-is.

The 2-hex sharding (`md5(sequence_id)[:2]`) keeps any one directory under ~500 entries,
which matters on network filesystems.

## Getting it

```bash
pip install huggingface_hub
hf download LaLa-World/openvid-frame-sequences-1M --repo-type dataset --local-dir openvid_seq
cd openvid_seq && for t in frames/*.tar; do tar -xf "$t"; done
```

## A line of `sequences.jsonl`

```json
{
  "id": "<clip>__w0",
  "video": "<clip>.mp4",
  "frames": ["frames/90/<clip>__w0/f00.jpg", "...", "frames/90/<clip>__w0/f09.jpg"],
  "timestamps": [0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5],
  "step_sec": 0.5,
  "n_frames": 10,
  "video_caption": "the original OpenVid caption for the whole clip",
  "meta": {"seconds": "...", "fps": "...", "motion": "...",
           "aesthetic": "...", "camera": "...", "hd": "1"}
}
```

Window `w` frame `i` is the source video at `w * 5.0 + i * 0.5` seconds.
`video_caption` is the OpenVid caption for the *entire* clip, not for this window —
it is useful as context for a captioning prompt, not as a label.

```python
import json
seqs = [json.loads(l) for l in open("sequences.jsonl")]
pairs = [(s["frames"][i], s["frames"][i+1], s) for s in seqs for i in range(9)]
len(pairs)   # 1,049,364
```

## Integrity

Every one of the 1,165,960 frame paths in `sequences.jsonl` was stat-checked against disk:
0 missing, 0 orphan JPEGs, 0 duplicate ids, 0 clips over the 2-sequence cap, all sequences
exactly 10 frames at exactly 0.5 s spacing, no sequence below the motion floor.
The 64 tars hold 1,282,812 entries = 1,165,960 JPEGs + 116,596 sequence dirs + 256 shard dirs.

## Known limitations

- **Shot changes: ~3.2% of sequences.** OpenVid's scene segmentation is not perfect, so a
  small fraction of sequences contain a cut. If a pair looks like two unrelated scenes,
  drop it. This is measurable — a single adjacent pair whose pixel delta is several times
  the sequence's own median is almost always a cut.
- **Residual talking-head footage.** The caption filter only matches
  `talk|talking|interview|podcast`, so clips where someone talks to the camera without those
  words in the caption (driving-and-talking, lecture footage) survive. Tighten
  `TALKING` in `scripts/select_clips.py` if that hurts your use case.
- `video_caption` describes the whole source clip, so it can mention things not visible in
  a given 4.5 s window.
- Frames are re-encoded JPEG at q=3 from already-compressed video; fine detail is lossy.

## Reproducing / extending

`scripts/` contains the full pipeline. `meta/manifest.csv` is fixed-order with a `cum_gb`
column, so raising the byte budget downloads only the next slice:

```bash
python3 scripts/fetch_clips.py --budget-gb 800 --workers 32   # this release used 600
python3 scripts/extract_frames.py --workers 176               # existing windows are skipped
python3 scripts/verify_dataset.py --full
```

| budget | clips | sequences | adjacent pairs |
|---|---|---|---|
| **600 GB** (this release) | 84,362 | 111,417 | 1,002,753 |
| 800 GB | 96,176 | 128,540 | 1,156,860 |
| 1,000 GB | 104,216 | 140,898 | 1,268,082 |
| 1,390 GB (all) | 111,536 | 153,391 | 1,380,519 |

This release has slightly more than the 600 GB row because 2,640 clips from beyond the
budget were already on disk and were extracted too.

Note for anyone pulling clips out of the OpenVid zips: `zipfile.ZipFile.read()` costs 3–4
HTTP round trips per member and Hugging Face throttles on request count, not bytes.
`scripts/hfzip.py:read_member()` fetches the local header and payload in one Range request
and parses it directly — 2.5× faster in practice (19 → 58 MB/s).

## License and attribution

**CC-BY-4.0**, inherited from OpenVid-1M. These are frames extracted from OpenVid-1M clips;
all credit for the underlying video collection and its captions goes to its authors.

```bibtex
@article{nan2024openvid,
  title   = {OpenVid-1M: A Large-Scale High-Quality Dataset for Text-to-video Generation},
  author  = {Nan, Kepan and Xie, Rui and Zhou, Penghao and Fan, Tiehan and
             Yang, Zhenheng and Chen, Zhijie and Li, Xiang and Yang, Jian and Tai, Ying},
  journal = {arXiv preprint arXiv:2407.02371},
  year    = {2024}
}
```

Intended for research use. The underlying clips are sourced from public video platforms;
the OpenVid authors' terms and takedown process apply to them.
