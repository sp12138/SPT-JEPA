---
tags:
  - benchmark
  - reinforcement-learning
  - ppo
  - robotics
  - paramtatva
license: apache-2.0
---

# MetaWorld Manipulation Benchmark

PPO evaluation benchmark on Meta-World manipulation tasks.

## Tasks

| Task ID | Name |
|---------|------|
| button-press-topdown-v3 | button-press-topdown-v3 |
| drawer-close-v3 | drawer-close-v3 |
| drawer-open-v3 | drawer-open-v3 |
| window-open-v3 | window-open-v3 |
| window-close-v3 | window-close-v3 |
| reach-v3 | reach-v3 |
| door-open-v3 | door-open-v3 |
| push-v3 | push-v3 |
| peg-insert-side-v3 | peg-insert-side-v3 |
| pick-place-v3 | pick-place-v3 |

## Usage

Submit evaluation results to this benchmark by adding `.eval_results/*.yaml` files
to your model repo, referencing this dataset's task IDs.

© 2026 ParamTatva.org
