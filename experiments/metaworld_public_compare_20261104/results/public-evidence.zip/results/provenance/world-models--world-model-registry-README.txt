---
license: apache-2.0
language:
- en
pretty_name: World Model Registry
tags:
- world-models
- world-model
- world-action-model
- physical-ai
- robotics
- simulation
- planning
size_categories:
- n<1K
---

# World Model Registry

**World Model Registry** is a curated, source-linked dataset for mapping the world-model ecosystem across Physical AI, robotics, learned simulation, planning and predictive representations.

**Version:** `0.1.0`  
**Last verified:** `2026-09-24`  
**Initial records:** `10`

## Why this registry exists

The label **world model** now covers several technical patterns:

```text
World Foundation Model
World Action Model
Interactive World Model
Planning World Model
Action-Conditioned Video World Model
Predictive Representation / World-Model Backbone
```

The registry makes those differences explicit instead of placing every model in one undifferentiated list.

## Core fields

- `repo_id`
- `organization`
- `model_name`
- `world_model_type`
- `architecture_family`
- `modalities`
- `domain`
- `action_conditioned`
- `interactive`
- `prediction_target`
- `planning_support`
- `control_support`
- `robotics`
- `physical_ai`
- `spatial_reasoning`
- `simulation`
- `synthetic_data`
- `parameter_count_b`
- `weights_available`
- `access_status`
- `license`
- `commercial_use`
- `base_model`
- `paper_id`
- `verification_status`
- `last_verified`
- `source_urls`
- `notes`

## Classification principles

```text
USE THE MODEL CARD
LINK THE SOURCE
SEPARATE DOCUMENTED FACTS FROM INTERPRETATION
MARK GAPS INSTEAD OF GUESSING
```

A model is only marked action-conditioned, interactive, planning-capable or control-capable when its documentation supports that property.

## Initial scope

The first release includes examples of:

- NVIDIA Cosmos Predict-2 world foundation models
- Cosmos Policy world-action / planning models
- Cosmos-H-Dreams interactive simulation
- τ₀-WM unified video-action world modeling
- A2World action-conditioned robotics simulation
- Boundless World Model
- V-JEPA 2 as a predictive representation / world-model backbone

## Important taxonomy note

Not every predictive video model is a full world model.

The registry therefore distinguishes between:

- full action-conditioned world models
- world foundation models
- interactive simulators
- planning models
- predictive representation backbones

This is particularly important for V-JEPA 2: the base checkpoint is action-free, while the associated research post-trains V-JEPA 2-AC as an action-conditioned world model for robotic planning.

## Intended uses

This dataset can support:

- model discovery
- world-model landscape mapping
- registry interfaces
- comparison tools
- robotics research
- Physical AI research
- planning research
- simulation research
- taxonomy analysis

## Limitations

This is an intentionally small first release.

It is not:

- a complete list of all world models
- a benchmark
- a model-quality ranking
- a legal opinion
- a safety certification

## Data architecture

```text
WORLD MODELS ORGANIZATION
        ↓
WORLD MODEL REGISTRY DATASET
        ↓
STRUCTURED TAXONOMY + VERIFIED METADATA
        ↓
WORLD MODEL REGISTRY SPACE
        ↓
SEARCH · FILTER · DETAILS · COMPARE
```

## Collaboration & Partnerships

The **World Models** organization is open to collaboration with world-model research teams, robotics companies, Physical AI companies, simulation platforms, research labs, universities and infrastructure providers.

Relevant collaboration areas include:

- verified registry contributions
- taxonomy
- world-action models
- interactive world models
- Physical AI
- robotics
- planning
- control
- simulation
- benchmarks
- dataset integration

**Collaboration:** `agenten@magenta.de`

## Independence

**World Models** is an independent Hugging Face community organization.

This registry is not an official registry of Hugging Face, NVIDIA, Meta, SII, BLM Lab or any other model developer listed here.

## License

The original registry structure, curation and documentation are released under **Apache-2.0**.

This does not relicense any listed model. Each model remains subject to its own license and terms.
