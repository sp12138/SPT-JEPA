# JEPA WM Extra Future RGB Delta

This HuggingFace dataset contains the extra CAM_F0 trainval RGB images needed by
the ReCogDrive JEPA-WM future-latent cache pipeline.

It is a delta over the standard NAVSIM/ReCogDrive trainval current-frame sensor
blob tree. The baseline is the union of current frame 3 CAM_F0 paths from
`required_jepa_frames.jsonl`. The included future frames are 5, 7, 9, and 11.

## Contents

- `delta_summary.json`: exact counts and frame-level occurrence audit.
- `required_jepa_frames.jsonl`: all required JEPA frame records.
- `extra_images_manifest.jsonl`: one record per extra RGB file in the delta.
- `jepa_wm_delta_20260630.tar.part-*`: split tar archive containing
  `sensor_blobs_delta/trainval/...`.
- `jepa_wm_delta_20260630.tar.part-*.sha256`: per-part checksums.

## Restore

Place all tar parts in one directory and run:

```bash
cat jepa_wm_delta_20260630.tar.part-* | tar -xf -
rsync -a sensor_blobs_delta/trainval/ /path/to/datasets/sensor_blobs/trainval/
```

Then validate from the project root:

```bash
python work/aaai-iclr-full/tools/validate_jepa_extra_delta.py \
  --required-jsonl required_jepa_frames.jsonl \
  --sensor-blobs-root /path/to/datasets/sensor_blobs/trainval \
  --delta-root .
```

Expected summary:

- copied/manifest images: 105,960
- extra occurrences by frame: frame 5 = 31,371; frame 7 = 50,625;
  frame 9 = 62,825; frame 11 = 69,595
- required records: 516,440
