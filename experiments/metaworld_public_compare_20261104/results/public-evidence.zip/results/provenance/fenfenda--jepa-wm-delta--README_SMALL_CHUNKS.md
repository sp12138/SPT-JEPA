# HF Upload Small Chunks

This directory contains the 256 MiB chunked upload layout for:

- JEPA WM extra future RGB delta tar stream
- `multi-experts-ad_20260630.tar.gz` migration package

## Upload

Use the sequential retry uploader from the project root:

```bash
cd /data/share/VLA-WM-Projs
./upload_small_chunks_to_hf_sequential.sh 2>&1 | tee hf_upload_small_chunks_20260701.log
```

The uploader sends one file at a time. If a file upload fails, it retries the
same file after `HF_UPLOAD_RETRY_SLEEP_SECONDS` seconds, default `60`.

## Restore JEPA Delta

After downloading the dataset files:

```bash
cd jepa_delta
sha256sum -c jepa_wm_delta_20260630.tar.chunks.sha256
cat chunks/jepa_wm_delta_20260630.tar.chunk-* | tar -xf -
rsync -a sensor_blobs_delta/trainval/ /path/to/datasets/sensor_blobs/trainval/
```

## Restore Migration Package

```bash
cd migration_package
sha256sum -c multi-experts-ad_20260630.tar.gz.chunks.sha256
cat chunks/multi-experts-ad_20260630.tar.gz.chunk-* > multi-experts-ad_20260630.tar.gz
sha256sum -c multi-experts-ad_20260630.tar.gz.sha256
```
